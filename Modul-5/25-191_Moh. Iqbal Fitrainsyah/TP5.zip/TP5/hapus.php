<?php
include 'koneksi.php';

$id = (int) $_GET['id'];

try {
    $stmt = mysqli_prepare($koneksi, "DELETE FROM supplier WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    header("Location: index.php");
} catch (mysqli_sql_exception $e) {
    echo "<script>alert('Supplier tidak dapat dihapus karena masih dipakai pada data barang.');
          window.location='index.php';</script>";
}
exit;
?>