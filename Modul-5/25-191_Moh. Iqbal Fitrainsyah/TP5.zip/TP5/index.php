<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Master Supplier</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <a href="tambah.php" class="btn btn-success pull-right" style="margin-top:20px">Tambah Data</a>
  <h3 style="color:#337ab7">Data Master Supplier</h3>
  <hr>
  <table class="table table-bordered table-hover">
    <thead>
      <tr class="info">
        <th>No</th><th>Nama</th><th>Telp</th><th>Alamat</th><th>Tindakan</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $no = 1;
    $query = mysqli_query($koneksi, "SELECT * FROM supplier ORDER BY id");
    while ($row = mysqli_fetch_assoc($query)) {
    ?>
      <tr>
        <td><?= $no++; ?></td>
        <td><?= htmlspecialchars($row['nama']); ?></td>
        <td><?= htmlspecialchars($row['telp']); ?></td>
        <td><?= htmlspecialchars($row['alamat']); ?></td>
        <td>
          <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Anda yakin akan menghapus supplier ini?')">Hapus</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>