<?php
include 'koneksi.php';

$id = (int) $_GET['id'];

if (isset($_POST['update'])) {
    $nama   = $_POST['nama'];
    $telp   = $_POST['telp'];
    $alamat = $_POST['alamat'];

    $stmt = mysqli_prepare($koneksi, "UPDATE supplier SET nama=?, telp=?, alamat=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, "sssi", $nama, $telp, $alamat, $id);
    mysqli_stmt_execute($stmt);

    header("Location: index.php");
    exit;
}

$result = mysqli_query($koneksi, "SELECT * FROM supplier WHERE id = $id");
$data   = mysqli_fetch_assoc($result);
if (!$data) { die("Data tidak ditemukan"); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Supplier</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <h2 style="color:#337ab7">Edit Data Master Supplier</h2>
  <hr>
  <form method="post" class="form-horizontal">
    <div class="form-group">
      <label class="col-sm-4 control-label">Nama</label>
      <div class="col-sm-5"><input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($data['nama']); ?>" required></div>
    </div>
    <div class="form-group">
      <label class="col-sm-4 control-label">Telp</label>
      <div class="col-sm-3"><input type="text" name="telp" maxlength="12" class="form-control" value="<?= htmlspecialchars($data['telp']); ?>" required></div>
    </div>
    <div class="form-group">
      <label class="col-sm-4 control-label">Alamat</label>
      <div class="col-sm-3"><input type="text" name="alamat" class="form-control" value="<?= htmlspecialchars($data['alamat']); ?>" required></div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-4 col-sm-5">
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-danger">Batal</a>
      </div>
    </div>
  </form>
</div>
</body>
</html>